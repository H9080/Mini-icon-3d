# Glass Mini Launcher

A starter Android home-screen launcher with a warm brown/gold glass look.

## Build APK
1. Install Android Studio (with Android SDK 35).
2. Open this `GlassMiniLauncher` folder in Android Studio.
3. Let Gradle sync finish.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK from `app/build/outputs/apk/debug/app-debug.apk`.
6. Press the phone's Home button and choose **Glass Mini Launcher**.

Minimum Android version: Android 8.0 (API 26).

## Included
- Home-screen launcher activity
- Installed-app grid (5 columns), tap an icon to open the app
- Search field for app filtering and web search
- Glass-style app tiles and generated brown/gold wallpaper
- Clock/date widget

Weather is currently a visual placeholder; live weather, icon pack customization, widgets, gestures, and drag-to-rearrange are not implemented in this starter build.
