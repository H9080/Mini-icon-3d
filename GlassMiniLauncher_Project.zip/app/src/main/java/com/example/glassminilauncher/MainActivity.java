package com.example.glassminilauncher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, grid;
    EditText search;
    ArrayList<ResolveInfo> apps = new ArrayList<>();
    PackageManager pm;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    GradientDrawable glass(int radius) {
        GradientDrawable d = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{0x99FFFFFF, 0x554A2A16, 0x8840200D});
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), 0x99F5C17B);
        return d;
    }

    TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0x22000000);
        getWindow().setNavigationBarColor(0x33000000);
        getWindow().getDecorView().setSystemUiVisibility(0);
        pm = getPackageManager();

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(10));
        root.setBackgroundResource(com.example.glassminilauncher.R.drawable.launcher_wallpaper);
        setContentView(root);

        LinearLayout widget = new LinearLayout(this);
        widget.setOrientation(LinearLayout.VERTICAL);
        widget.setPadding(dp(18), dp(16), dp(18), dp(16));
        widget.setBackground(glass(26));
        TextView clock = text(new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(new java.util.Date()), 42, Color.WHITE, true);
        TextView date = text(new java.text.SimpleDateFormat("EEEE, d MMM", java.util.Locale.getDefault()).format(new java.util.Date()), 15, 0xFFE8D9CC, false);
        TextView weather = text("☀  Weather widget  •  Tap to refresh\nSet your city in a future update", 14, Color.WHITE, false);
        weather.setPadding(0, dp(12), 0, 0);
        widget.addView(clock); widget.addView(date); widget.addView(weather);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, -2);
        wp.bottomMargin = dp(22); root.addView(widget, wp);

        TextView heading = text("YOUR APPS", 11, 0xFFD9B58B, true);
        heading.setLetterSpacing(0.16f);
        root.addView(heading);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(grid);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1f);
        sp.topMargin = dp(10); root.addView(scroll, sp);

        LinearLayout searchBar = new LinearLayout(this);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(dp(15), dp(8), dp(12), dp(8));
        searchBar.setBackground(glass(30));
        TextView g = text("G", 26, 0xFFFFC24D, true);
        searchBar.addView(g);
        search = new EditText(this);
        search.setSingleLine(true); search.setTextColor(Color.WHITE); search.setHintTextColor(0xFFDDC9B5);
        search.setHint("Search apps or the web"); search.setTextSize(14);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setPadding(dp(14), 0, 0, 0);
        searchBar.addView(search, new LinearLayout.LayoutParams(0, dp(42), 1));
        TextView go = text("⌕", 27, Color.WHITE, true);
        searchBar.addView(go);
        go.setOnClickListener(v -> webSearch());
        search.setOnEditorActionListener((v, action, event) -> { webSearch(); return true; });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(12); root.addView(searchBar, bp);

        loadApps();
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ showApps(s.toString()); }
            public void afterTextChanged(Editable e){}
        });
    }

    void webSearch() {
        String q = search.getText().toString().trim();
        if (q.isEmpty()) return;
        try { startActivity(new Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q)); }
        catch(Exception e) { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(q)))); }
    }

    void loadApps() {
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        apps = new ArrayList<>(pm.queryIntentActivities(intent, 0));
        Collections.sort(apps, (a,b) -> a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
        showApps("");
    }

    void showApps(String filter) {
        if (grid == null) return;
        grid.removeAllViews();
        ArrayList<ResolveInfo> visible = new ArrayList<>();
        for (ResolveInfo r : apps) {
            String label = r.loadLabel(pm).toString();
            if (label.toLowerCase().contains(filter.toLowerCase())) visible.add(r);
        }
        int columns = 5;
        for (int i=0; i<visible.size(); i+=columns) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.TOP);
            for (int j=i; j<Math.min(i+columns, visible.size()); j++) {
                ResolveInfo info = visible.get(j);
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(dp(2), dp(8), dp(2), dp(10));
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
                row.addView(cell, cp);

                FrameLayout iconFrame = new FrameLayout(this);
                iconFrame.setBackground(glass(17));
                iconFrame.setElevation(dp(5));
                ImageView icon = new ImageView(this);
                try { icon.setImageDrawable(info.loadIcon(pm)); } catch(Exception ignored) {}
                icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
                FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(35), dp(35), Gravity.CENTER);
                iconFrame.addView(icon, ip);
                cell.addView(iconFrame, new LinearLayout.LayoutParams(dp(54), dp(54)));
                TextView label = text(info.loadLabel(pm).toString(), 9, Color.WHITE, false);
                label.setGravity(Gravity.CENTER); label.setMaxLines(1); label.setEllipsize(android.text.TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.topMargin = dp(4); cell.addView(label, lp);
                cell.setOnClickListener(v -> {
                    try { startActivity(pm.getLaunchIntentForPackage(info.activityInfo.packageName)); }
                    catch(Exception ignored) {}
                });
            }
            grid.addView(row);
        }
        if (visible.isEmpty()) {
            TextView empty = text("No apps found", 14, Color.WHITE, false);
            empty.setPadding(0, dp(20), 0, 0); grid.addView(empty);
        }
    }

    @Override public void onResume() { super.onResume(); if (pm != null) loadApps(); }
}